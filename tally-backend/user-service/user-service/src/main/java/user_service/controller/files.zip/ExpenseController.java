package user_service.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import user_service.model.Expense;
import user_service.service.ExpenseService;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Handles all expense-related API requests at /api/expenses.
 * Delegates logic to ExpenseService.
 */
@RestController
@RequestMapping("/api/expenses")
@CrossOrigin(origins = "*")
public class ExpenseController {

    @Autowired
    private ExpenseService expenseService;

    /**
     * POST /api/expenses
     * Creates a new expense for a user.
     * Required fields: userId, amount, category, date
     * Optional fields: description, paymentMethod (defaults to CASH)
     */
    @PostMapping
    public ResponseEntity<?> createExpense(@RequestBody Map<String, String> request) {
        try {
            String userIdStr = request.get("userId");
            String amountStr = request.get("amount");
            String category = request.get("category");
            String dateStr = request.get("date");

            if (userIdStr == null || amountStr == null || category == null || dateStr == null) {
                return ResponseEntity.badRequest()
                        .body(Map.of("error", "userId, amount, category and date are required", "success", false));
            }

            if (category.isEmpty()) {
                return ResponseEntity.badRequest()
                        .body(Map.of("error", "Category cannot be empty", "success", false));
            }

            Long userId = Long.parseLong(userIdStr);
            BigDecimal amount = new BigDecimal(amountStr);

            if (amount.compareTo(BigDecimal.ZERO) <= 0) {
                return ResponseEntity.badRequest()
                        .body(Map.of("error", "Amount must be greater than zero", "success", false));
            }

            String description = request.get("description");
            String paymentMethod = request.getOrDefault("paymentMethod", "CASH");
            LocalDate date = LocalDate.parse(dateStr);

            Expense expense = expenseService.createExpense(userId, amount, category, description, date, paymentMethod);
            return ResponseEntity.status(HttpStatus.CREATED).body(expense);

        } catch (Exception e) {
            return ResponseEntity.badRequest()
                    .body(Map.of("error", e.getMessage(), "success", false));
        }
    }

    /**
     * GET /api/expenses/user/{userId}
     * Returns all expenses for a user.
     * Optional query param: category — filters results by category.
     * Example: /api/expenses/user/1?category=Food
     */
    @GetMapping("/user/{userId}")
    public ResponseEntity<?> getUserExpenses(@PathVariable Long userId,
                                             @RequestParam(required = false) String category) {
        try {
            List<Expense> expenses;
            if (category != null && !category.isEmpty()) {
                expenses = expenseService.getUserExpensesByCategory(userId, category);
            } else {
                expenses = expenseService.getUserExpenses(userId);
            }
            return ResponseEntity.ok(expenses);
        } catch (Exception e) {
            return ResponseEntity.badRequest()
                    .body(Map.of("error", e.getMessage(), "success", false));
        }
    }

    /**
     * DELETE /api/expenses/{expenseId}
     * Deletes a single expense by its ID.
     */
    @DeleteMapping("/{expenseId}")
    public ResponseEntity<?> deleteExpense(@PathVariable Long expenseId) {
        try {
            expenseService.deleteExpense(expenseId);
            return ResponseEntity.ok(Map.of("message", "Expense deleted successfully", "success", true));
        } catch (Exception e) {
            return ResponseEntity.badRequest()
                    .body(Map.of("error", e.getMessage(), "success", false));
        }
    }

    /**
     * GET /api/expenses/user/{userId}/report
     * Returns a monthly spending report for a user.
     * Optional query params: month, year — defaults to current month/year.
     * Example: /api/expenses/user/1/report?month=6&year=2026
     */
    @GetMapping("/user/{userId}/report")
    public ResponseEntity<?> getMonthlyReport(@PathVariable Long userId,
                                              @RequestParam(required = false) Integer month,
                                              @RequestParam(required = false) Integer year) {
        try {
            Map<String, Object> report = expenseService.getMonthlyReport(userId, month, year);
            // Copy to new map so we don't mutate the service-returned object
            Map<String, Object> response = new HashMap<>(report);
            response.put("success", true);
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            return ResponseEntity.badRequest()
                    .body(Map.of("error", e.getMessage(), "success", false));
        }
    }

    /**
     * GET /api/expenses/user/{userId}/history
     * Returns a combined history of all expenses for a user.
     */
    @GetMapping("/user/{userId}/history")
    public ResponseEntity<?> getCombinedHistory(@PathVariable Long userId) {
        try {
            return ResponseEntity.ok(expenseService.getCombinedHistory(userId));
        } catch (Exception e) {
            return ResponseEntity.badRequest()
                    .body(Map.of("error", e.getMessage(), "success", false));
        }
    }
}
